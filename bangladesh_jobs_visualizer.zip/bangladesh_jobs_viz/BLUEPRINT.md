# Bangladesh Job Market Visualizer — Full Engineering Blueprint

> **Adapted from Andrej Karpathy's [karpathy/jobs](https://github.com/karpathy/jobs) architecture for the Bangladesh workforce.**  
> Data Year: BBS Labour Force Survey 2023 · Total labour force: 71.1M workers  
> Architecture: Data ingestion → LLM scoring → D3.js interactive treemap

---

## 1. CREDIBLE DATA SOURCE MAPPING

### 1.1 Primary Employment Data

| Source | Data Available | Access |
|--------|---------------|--------|
| **BBS Labour Force Survey 2023** (Annual) | Occupation by ISCO-08, employment by sector (agriculture 44.4%, industry 17.3%, services 38.3%), sex-disaggregated | [bbs.gov.bd](https://bbs.gov.bd/site/page/111d09ce-718a-4ae6-8188-f7d938ada348/labor-&-employment) · Free PDF/XLSX |
| **BBS Labour Force Survey 2022** (ILO microdata) | ISCO-08 4-digit occupation codes, BSIC industry codes, individual-level | [ILO Survey Catalogue](https://webapps.ilo.org/surveyLib/index.php/catalog/8538) · Free |
| **BGMEA (Bangladesh Garment Manufacturers & Exporters Association)** | 3.317M woven + 1.7M knit = 5.017M RMG workers (Parliamentary, June 2024) | bgmea.com.bd |
| **BMET (Bureau of Manpower, Employment & Training)** | 1.303M overseas workers dispatched in 2023; cumulative stock abroad | bmet.gov.bd |
| **Bangladesh Economic Zones Authority (BEZA)** | Special Economic Zone employment by industry | beza.gov.bd |

**Key aggregate (BBS LFS 2023 Q1):**
- Total employed: **71.10M** (46.54M male, 24.56M female)
- Agriculture: **31.94M** (44.9% of employed)
- Industry: **12.25M** (17.2%)
- Services: **26.91M** (37.9%)

### 1.2 Wage & Salary Data

| Source | Coverage | Notes |
|--------|----------|-------|
| **BBS Wage Rate Survey** | Sector-level daily/monthly wage by occupation | Annual; free download from bbs.gov.bd |
| **8th National Pay Scale 2015** (GoB) | All 20 government pay grades (Grade 9 BCS entry: BDT 22,000 basic + allowances ≈ BDT 33,100 total) | gazette.gov.bd; increments +5% annually |
| **RMG Minimum Wage Board Gazette (Dec 2023)** | Grade 4 entry: BDT 12,500/month (56% increase from 2018's BDT 8,000) | Official gazette notification |
| **Glassdoor BD / PayScale BD** | IT/software: BDT 35K–65K/month average; Senior: BDT 80K–150K | Market data, cross-check with BBS |
| **Fair Labor Association Wage Trends Report 2024** | RMG wages by grade, year-on-year trends | fairlabor.org |
| **BRAC Institute studies** | NGO/development sector salary surveys | bracinstitute.net |

### 1.3 Occupational Taxonomy Standard

Bangladesh uses **two parallel frameworks** — map between them:

**BSCO (Bangladesh Standard Classification of Occupations)**
- Based on ILO ISCO-08 (International Standard Classification of Occupations, Revision 2008)
- Published by BBS; aligns 4-digit SOC codes to local occupational titles in Bangla and English
- Source: `bbs.portal.gov.bd` → Publications → "National Occupational Classification BSCO"
- Covers 10 Major Groups → 43 Sub-Major → 130 Minor → 436 Unit Groups

**NSDA NTVQF (National Technical and Vocational Qualifications Framework)**
- Published by National Skills Development Authority under the NSDA Act 2018
- 8-level competency framework for TVET occupations
- Maps directly to ISCO skill levels 1-4
- Source: `nsda.portal.gov.bd` → NTVQF documentation

**Mapping Strategy for this project:**
```
BSCO 4-digit code → ISCO-08 equivalent → BBS LFS employment count → local wage data
```

### 1.4 Education Requirement Data

- **Bangladesh Education Statistics 2022** (BANBEIS): enrollment by level, completion rates
- **NSDA NTVQF Level Descriptors**: 8 competency levels mapped to education qualifications
- **BBS LFS microdata**: `edu_level` variable in ISCO-08 coded records

---

## 2. SYSTEM ARCHITECTURE & DATA SCHEMA

### 2.1 Pipeline Overview (Mirroring karpathy/jobs)

```
[BBS LFS Excel/CSV] → [parse_bbs.py] → [occupations.csv]
                                              ↓
[Job descriptions (manual/scraped)]  → [score.py + LLM] → [scores.json]
                                              ↓
                               [build_site_data.py] → [site/data.json]
                                              ↓
                                    [site/index.html] → Interactive Treemap
```

### 2.2 `occupations.json` Schema

Full list of 46+ representative Bangladeshi occupations. Each entry:

```json
{
  "slug": "software-engineer",
  "title": "Software Engineer / Developer",
  "category": "IT & Digital",
  "sector": "Professional",
  "description": "Designs, codes, tests, and deploys software applications. Work product is entirely digital — code, documentation, APIs. Can work remotely. Heavily uses AI coding tools like GitHub Copilot."
}
```

**46 occupations across 8 sectors covered:**
- Agriculture (7): Rice farmer, vegetable farmer, jute worker, fisherman, poultry farmer, agricultural day laborer, shrimp farmer
- Ready-Made Garments (5): Sewing operator, QC inspector, cutting worker, supervisor, merchandiser
- Manufacturing (4): Textile spinner, factory machine operator, shipbuilding worker, general factory
- Construction (4): Day laborer, mason/carpenter, electrician/plumber, civil works
- Services (8): Retail, rickshaw, ride-sharing, truck/bus driver, restaurant, domestic worker, salon, mobile banking agent
- Financial / NGO (3): Bank officer, microfinance officer, mobile banking agent
- Professional (12): Software engineer, data analyst, IT support, BCS officer, teacher (3 levels), professor, doctor, nurse, journalist, accountant, lawyer, engineer, NGO worker
- Migrant Labor (1): Overseas workers (Gulf/Malaysia)

### 2.3 `site/data.json` Schema

The merged dataset powering the frontend visualization:

```json
{
  "meta": {
    "title": "Bangladesh Job Market Visualizer",
    "total_workforce_millions": 71.1,
    "data_year": 2023,
    "primary_source": "BBS Labour Force Survey 2023",
    "wage_currency": "BDT",
    "wage_period": "monthly"
  },
  "education_tiers": {
    "1": "No formal education / Illiterate",
    "2": "Primary (Class 1-5)",
    "3": "Secondary / SSC",
    "4": "Higher Secondary / HSC",
    "5": "Vocational / TVET Certificate",
    "6": "Bachelor's Degree",
    "7": "Master's / Postgraduate",
    "8": "Medical / Professional Degree"
  },
  "occupations": [
    {
      "slug": "software-engineer",
      "title": "Software Engineer / Developer",
      "category": "IT & Digital",
      "headcount": 400000,
      "avg_monthly_wage_bdt": 65000,
      "education_tier": 6,
      "education_label": "Bachelor's Degree",
      "ai_exposure": 9,
      "ai_rationale": "Work product is entirely digital code and documentation..."
    }
  ]
}
```

**Key field definitions:**
| Field | Type | Source | Notes |
|-------|------|--------|-------|
| `headcount` | integer | BBS LFS 2023 / BGMEA / BMET | Total employed nationally |
| `avg_monthly_wage_bdt` | integer | BBS Wage Survey / Pay Scale / Glassdoor BD | Median monthly, includes allowances |
| `education_tier` | 1-8 | NSDA NTVQF / BANBEIS | Minimum qualification typical for entry |
| `ai_exposure` | 0-10 | LLM-scored (score.py) | Digital AI disruption potential |
| `ai_rationale` | string | LLM-generated | 2-3 sentence Bangladesh-specific explanation |

---

## 3. BANGLADESH-SPECIFIC AI EXPOSURE SCORING RUBRIC

### 3.1 System Prompt Design

The scoring prompt is adapted from Karpathy's original but **calibrated for Bangladesh's economic context**:

**Critical Bangladesh-specific calibrations:**
1. **Digital infrastructure gap**: Rural internet penetration ~35%; smartphone penetration ~50%; cash-based informal economy (85%+ informal workers)
2. **Language dimension**: LLMs proficient in Bangla already — call centers and content writing face immediate disruption
3. **Wage economics**: At BDT 12,500/month minimum wage, automation ROI calculations differ from US/Europe
4. **Sector specificity**: RMG factory automation vs. agricultural informality vs. Dhaka IT ecosystem

**Two core dimensions scored:**

| Dimension | Weight | Description |
|-----------|--------|-------------|
| **Output Digitality** | 50% | Is the work product entirely digital (code, text, data, reports)? |
| **Physical Presence** | 50% | Does the role require physical presence, dexterity, or in-person interaction within Bangladesh's infrastructure? |

**Score = (Output Digitality Score × 0.5) + ((10 - Physical Presence Score) × 0.5)**

### 3.2 `score.py` — Full LLM Scoring Pipeline

```python
#!/usr/bin/env python3
"""
score.py — Bangladesh Job Market AI Exposure Scoring Pipeline
Adapted from Andrej Karpathy's karpathy/jobs architecture.
Uses Google Gemini Flash (via OpenRouter) to score occupations.

Usage:
    pip install openai python-dotenv
    OPENROUTER_API_KEY=your_key python score.py
"""

import json, os, time
from pathlib import Path
from openai import OpenAI
from dotenv import load_dotenv

load_dotenv()
client = OpenAI(
    base_url="https://openrouter.ai/api/v1",
    api_key=os.environ["OPENROUTER_API_KEY"],
)

SYSTEM_PROMPT = """You are a labor economist specializing in the Bangladesh workforce 
and the impact of digital AI on South Asian occupational categories.

Score each occupation's "Digital AI Exposure" from 0 to 10.

DEFINITION: Measures how much CURRENT AI (LLMs, computer vision, RPA, generative AI) 
can reshape the CORE TASKS in the context of BANGLADESH's economy and infrastructure.

SCORING RUBRIC:
9-10 (Very High): Entirely digital output (code, text, data, reports). Remoteable.
7-8  (High): Mostly digital; AI automates significant portions.
5-6  (Moderate): Mix of digital and physical; AI augments but not substitutes.
3-4  (Low-Moderate): Primarily physical; some digital tools at the periphery.
1-2  (Very Low): Physical, manual, location-bound in Bangladesh.
0    (None): Entirely physical; zero digital work product.

BANGLADESH CALIBRATIONS:
- Rural internet: ~35% penetration; cash-based informal economy dominates
- LLMs speak Bangla well — call centers and content creation face immediate risk
- At BDT 12,500/mo minimum wage, automation ROI differs from Global North
- Consider field-based work in floods, rural infrastructure, rickshaw traffic

Respond ONLY with JSON: {"exposure": <0-10>, "rationale": "<2-3 sentences>"}
"""

def score_occupation(occ: dict) -> dict:
    user_content = f"""
Occupation: {occ['title']}
Sector: {occ['sector']} | Category: {occ['category']}
Description: {occ['description']}

Score Digital AI Exposure (0-10) for the Bangladesh workforce context.
"""
    response = client.chat.completions.create(
        model="google/gemini-flash-1.5",
        messages=[
            {"role": "system", "content": SYSTEM_PROMPT},
            {"role": "user", "content": user_content}
        ],
        temperature=0.3,
        max_tokens=300,
    )
    raw = response.choices[0].message.content.strip()
    if raw.startswith("```"):
        raw = raw.split("```")[1].lstrip("json").strip()
    return json.loads(raw)

# Load occupations
with open("occupations.json") as f:
    occupations = json.load(f)

scores_path = Path("scores.json")
scores = json.loads(scores_path.read_text()) if scores_path.exists() else {}

for i, occ in enumerate(occupations):
    slug = occ["slug"]
    if slug in scores:
        print(f"[{i+1}/{len(occupations)}] SKIP {occ['title']}")
        continue
    print(f"[{i+1}/{len(occupations)}] Scoring: {occ['title']}...", end=" ")
    try:
        result = score_occupation(occ)
        scores[slug] = {"title": occ["title"], **result}
        print(f"→ {result['exposure']}/10")
        scores_path.write_text(json.dumps(scores, indent=2))  # resume-safe
        time.sleep(0.5)
    except Exception as e:
        print(f"ERROR: {e}")

print(f"\n✅ Scored {len(scores)} occupations → scores.json")
```

### 3.3 Expected AI Exposure Score Distribution (Bangladesh)

| Score Range | Count | Example Occupations |
|-------------|-------|---------------------|
| 9-10 | 2 | Software Engineer (9), — |
| 7-8 | 7 | Data Analyst (8), Freelance Digital Worker (8), Call Center Agent (8), Bank Officer (7), Journalist (7), Accountant (7) |
| 5-6 | 8 | BCS Officer (5), NGO Worker (5), Medical Doctor (5), Engineer (5), Lawyer (6), University Professor (6), IT Support (6), Garments Merchandiser (6) |
| 3-4 | 9 | RMG Supervisor (4), Microfinance Officer (4), Secondary Teacher (4), Mobile Banking Agent (4), Ride-sharing Driver (3), Retail Worker (3), Factory Operator (3) |
| 1-2 | 20 | Rice Farmer (1), Rickshaw Puller (1), RMG Operator (2), Construction Worker (1), Fisherman (2), Domestic Worker (1) |

**Key Bangladesh insight:** 55-60% of the workforce is in physical/manual labour scoring ≤2 — agriculture, RMG factory floor, construction, and informal services. Only ~12M workers (17%) are in occupations with meaningful digital AI exposure.

---

## 4. FRONTEND VISUALIZATION BLUEPRINT

### 4.1 Architecture

The frontend is a **single self-contained HTML file** (`site/index.html`) requiring no build step or server-side dependencies (only the D3.js CDN link).

```
site/
├── index.html      ← Complete app (HTML + CSS + JS + inline data)
└── data.json       ← External data file (or inline for portability)
```

### 4.2 D3.js Treemap Implementation

**Library:** D3.js v7 via CDN (`https://d3js.org/d3.v7.min.js`)

**Key D3 APIs used:**
- `d3.hierarchy()` — builds parent-child tree from grouped occupation data
- `d3.treemap()` — squarified layout with `.paddingOuter(4).paddingInner(2).paddingTop(20)`
- `d3.scaleSequential()` — continuous color scale for wage visualization
- `d3.group()` — groups occupations by category for sector-level parent nodes

**Color encoding logic:**

```javascript
// AI Exposure: discrete 10-color palette (navy → orange)
const AI_COLORS = ["#1e3a5f","#1d4e89",...,"#f57c00","#e65100"];

// Wage: sequential scale BDT 7,000–85,000
const WAGE_SCALE = d3.scaleSequential()
  .domain([7000, 85000])
  .interpolator(d3.interpolateRgb("#1a2a4a", "#e65100"));

// Education: discrete 8-tier categorical colors
// Headcount: category-level colors (Agriculture=green, RMG=red, IT=blue, etc.)
```

### 4.3 Toggle Controls

Four metric toggles with `data-metric` attributes:

| Button | Metric | Color Logic |
|--------|--------|-------------|
| 👥 Headcount | `headcount` | Category color per sector |
| 🤖 Digital AI Exposure | `ai_exposure` | 0-9 discrete blue→orange scale |
| 💰 Monthly Wage (BDT) | `wage` | Sequential dark-blue → orange |
| 🎓 Education Tier | `education` | 8-tier categorical palette |

### 4.4 Tooltip Schema

On hover, each cell displays:
```
[Occupation Title]
Category:      [e.g., Ready-Made Garments]
Workers:       [e.g., 3.32M (3,317,397)]
Monthly Wage:  ৳13,500 BDT
Education:     Secondary / SSC
────────────────────
🤖 AI Exposure:  [2/10] badge
"Work is highly repetitive but requires manual dexterity..."
```

### 4.5 Responsive Design

- SVG `viewBox` recalculated on `window.resize`
- Label rendering conditioned on cell dimensions: labels shown only when `width > 55px && height > 26px`
- Sub-labels (wage, AI score, headcount) shown only when `width > 80px && height > 65px`

---

## 5. DEPLOYMENT SETUP

### 5.1 Repository Structure

```
bangladesh-jobs/
├── README.md
├── occupations.json         ← 46 occupation definitions (source of truth)
├── occupations.csv          ← Tabulated stats (generated by build_stats.py)
├── scores.json              ← LLM AI exposure scores (generated by score.py)
├── score.py                 ← LLM scoring pipeline (Gemini Flash via OpenRouter)
├── build_site_data.py       ← Merges CSV + scores → site/data.json
├── pyproject.toml           ← Python dependencies
├── .env                     ← OPENROUTER_API_KEY (gitignored)
└── site/
    ├── index.html           ← Complete interactive visualization
    └── data.json            ← Merged dataset for frontend
```

### 5.2 `build_site_data.py`

```python
"""Merges occupations.csv + scores.json → site/data.json"""
import json, csv, pathlib

with open('occupations.csv') as f:
    occ_rows = {row['slug']: row for row in csv.DictReader(f)}
with open('scores.json') as f:
    scores = json.load(f)

occupations = []
for slug, row in occ_rows.items():
    score_data = scores.get(slug, {"exposure": -1, "rationale": "Not yet scored"})
    occupations.append({
        "slug": slug,
        "title": row["title"],
        "category": row["category"],
        "headcount": int(row["headcount"]),
        "avg_monthly_wage_bdt": int(row["avg_monthly_wage_bdt"]),
        "education_tier": int(row["education_tier"]),
        "education_label": row["education_label"],
        "ai_exposure": score_data["exposure"],
        "ai_rationale": score_data["rationale"],
    })

site_data = {
    "meta": {"title": "Bangladesh Job Market Visualizer", 
             "total_workforce_millions": 71.1, "data_year": 2023,
             "primary_source": "BBS Labour Force Survey 2023"},
    "education_tiers": {
        "1": "No formal education", "2": "Primary (Class 1-5)",
        "3": "Secondary / SSC",     "4": "Higher Secondary / HSC",
        "5": "Vocational / TVET",   "6": "Bachelor's Degree",
        "7": "Master's / Postgraduate", "8": "Medical / Prof. Degree"
    },
    "occupations": occupations
}

pathlib.Path('site/data.json').write_text(json.dumps(site_data, indent=2))
print(f"Built site/data.json with {len(occupations)} occupations")
```

### 5.3 Quick Start

```bash
# 1. Install dependencies
pip install openai python-dotenv

# 2. Set API key
echo "OPENROUTER_API_KEY=your_key_here" > .env

# 3. Run AI scoring pipeline
python score.py

# 4. Build site data
python build_site_data.py

# 5. Serve locally
cd site && python -m http.server 8000
# Open http://localhost:8000
```

### 5.4 Extending the Scoring Rubric

The modular `score.py` allows rerunning with alternative prompts. Suggested Bangladesh-specific alternative analyses:

| Prompt Variant | What it measures |
|----------------|-----------------|
| **Offshoring Risk** | Can this job be moved abroad / performed remotely by a foreign worker? |
| **Climate Vulnerability** | How exposed is this occupation to Bangladesh's flood, cyclone, and heat risks? |
| **Female Labour Concentration** | What share of these workers are women? (intersects with automation risk) |
| **Remittance Sector Overlap** | Are skills transferable to Gulf/Malaysia migration pathways? |
| **Digital Literacy Prerequisite** | What minimum smartphone/internet skill does this job actually require today? |

---

## 6. KNOWN DATA LIMITATIONS & CALIBRATION NOTES

1. **BBS LFS occupation granularity**: The public LFS report provides 3-major-sector breakdowns. ISCO-08 4-digit occupation data requires the BBS microdata request (free but requires formal application via bbs.gov.bd).

2. **Informal economy dominance**: BBS counts anyone working even 1 hour in the reference week as "employed." ~85% of Bangladesh workers are informal — wage data for these categories relies on BBS Wage Rate Survey averages, which may undercount or use daily-wage-to-monthly conversions.

3. **RMG double-counting**: BGMEA reports ~3.317M woven workers; BKMEA reports 1.7M knit workers; BBS LFS 2022 reports 4.316M total. Parliamentary statement (June 2024) cites 5.017M. This blueprint uses BGMEA/BKMEA split for woven/knit distinction and BBS for aggregate.

4. **IT/digital sector undercount**: BBS LFS likely undercounts freelancers as Bangladesh has 600,000–800,000 registered freelancers on Upwork/Fiverr but many are not captured as formal employees.

5. **Wage data vintage**: BBS National Pay Scale was last revised in 2015. A 2026 proposal recommends near-doubling of grades (Grade 20: BDT 8,250 → BDT 20,000; Grade 9 BCS entry: BDT 22,000 → BDT 50,000 estimated). When enacted, wages in `data.json` should be updated.

6. **AI scores are LLM estimates**: Following Karpathy's own disclaimer — these are rough LLM estimates, not rigorous econometric predictions. They reflect task structure, not employment quantity outcomes.
